import http from "node:http";
import { WebSocketServer } from "ws";
import crypto from "node:crypto";

const PORT = Number(process.env.PORT || 8080);
const devices = new Map();
const sessions = new Map();

function makePairCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function send(ws, payload) {
  if (ws.readyState === 1) ws.send(JSON.stringify(payload));
}

const httpServer = http.createServer((req, res) => {
  res.writeHead(200, {"content-type": "application/json"});
  res.end(JSON.stringify({
    name: "Neko Remote Support Server",
    devices: devices.size,
    sessions: sessions.size
  }));
});

const wss = new WebSocketServer({ server: httpServer });

wss.on("connection", (ws) => {
  let deviceId = null;
  let role = null;

  send(ws, {
    type: "hello",
    message: "Connected to Neko Remote Support"
  });

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return send(ws, {type: "error", message: "Invalid JSON"});
    }

    if (msg.type === "register") {
      deviceId = String(msg.deviceId || crypto.randomUUID());
      role = "device";

      const pairCode = makePairCode();
      devices.set(deviceId, {
        id: deviceId,
        name: String(msg.name || "Android Device"),
        model: String(msg.model || "Unknown"),
        sdk: Number(msg.sdk || 0),
        online: true,
        pairCode,
        ws,
        updatedAt: Date.now()
      });

      send(ws, {
        type: "registered",
        deviceId,
        pairCode
      });
      return;
    }

    if (msg.type === "pair") {
      const code = String(msg.code || "");
      const found = [...devices.values()].find(d => d.pairCode === code);

      if (!found) {
        return send(ws, {type: "pair_result", ok: false});
      }

      role = "operator";
      const sessionId = crypto.randomUUID();
      sessions.set(sessionId, {
        operator: ws,
        device: found.ws,
        deviceId: found.id
      });

      send(ws, {
        type: "pair_result",
        ok: true,
        sessionId,
        device: {
          id: found.id,
          name: found.name,
          model: found.model,
          sdk: found.sdk
        }
      });

      send(found.ws, {
        type: "remote_request",
        sessionId,
        message: "A remote-support session was requested. Approve it in the app."
      });
      return;
    }

    if (msg.type === "approve_session") {
      const session = sessions.get(String(msg.sessionId || ""));
      if (!session || session.device !== ws) return;

      send(session.operator, {
        type: "session_approved",
        sessionId: String(msg.sessionId)
      });
      return;
    }

    if (msg.type === "command") {
      const session = sessions.get(String(msg.sessionId || ""));
      if (!session || session.operator !== ws) return;

      const command = String(msg.command || "");
      const allowed = new Set(["PING", "DEVICE_INFO"]);

      if (!allowed.has(command)) {
        return send(ws, {
          type: "command_result",
          ok: false,
          message: "Command not allowed"
        });
      }

      send(session.device, {
        type: "command_request",
        sessionId: String(msg.sessionId),
        command
      });
      return;
    }

    if (msg.type === "command_result") {
      const session = sessions.get(String(msg.sessionId || ""));
      if (!session || session.device !== ws) return;

      send(session.operator, {
        type: "command_result",
        ok: true,
        command: msg.command,
        data: msg.data ?? null
      });
      return;
    }

    if (msg.type === "revoke") {
      const id = String(msg.deviceId || "");
      const device = devices.get(id);
      if (!device) return;

      if (device.ws && device.ws.readyState === 1) {
        send(device.ws, {type: "revoked"});
        device.ws.close();
      }
      devices.delete(id);
    }
  });

  ws.on("close", () => {
    if (deviceId && devices.has(deviceId)) {
      const d = devices.get(deviceId);
      d.online = false;
      d.updatedAt = Date.now();
    }

    for (const [id, session] of sessions) {
      if (session.operator === ws || session.device === ws) {
        const other = session.operator === ws ? session.device : session.operator;
        send(other, {type: "session_closed", sessionId: id});
        sessions.delete(id);
      }
    }
  });
});

httpServer.listen(PORT, () => {
  console.log(`Neko Remote Support listening on http://0.0.0.0:${PORT}`);
});
