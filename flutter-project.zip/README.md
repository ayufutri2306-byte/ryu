# Neko Remote Support

Project remote-support Android + Node.js WebSocket server.

Fitur:
- Pairing menggunakan kode 6 digit
- Registrasi perangkat
- Dashboard status perangkat
- Informasi perangkat dasar
- Perintah ping
- Log aktivitas
- Revoke pairing
- Notifikasi sesi remote di aplikasi

Project ini tidak memiliki akses tersembunyi, keylogger, pengambilan file diam-diam, persistence tersembunyi, atau kontrol perangkat tanpa persetujuan.

## Struktur

- `android/` aplikasi Android Kotlin
- `server/` backend Node.js WebSocket

## Menjalankan server

```bash
cd server
npm install
npm start
```

Server berjalan pada port 8080.

## Android

Buka folder `android/` menggunakan Android Studio, lalu build project.

Atur URL server pada `MainActivity.kt` jika memakai alamat server berbeda.

Minimum SDK: 26.
