package com.neko.remotesupport

import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var codeView: TextView
    private lateinit var logView: TextView
    private lateinit var socket: WebSocket

    private val serverUrl = "ws://10.0.2.2:8080"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        status = TextView(this).apply { text = "Status: connecting..." }
        codeView = TextView(this).apply { text = "Pair code: -" }
        logView = TextView(this).apply { text = "Activity log\n" }

        val pingButton = Button(this).apply {
            text = "Respond to PING"
            setOnClickListener {
                addLog("Local support check requested")
            }
        }

        root.addView(status)
        root.addView(codeView)
        root.addView(pingButton)
        root.addView(logView)

        setContentView(root)
        connect()
    }

    private fun connect() {
        val client = OkHttpClient()

        val request = Request.Builder()
            .url(serverUrl)
            .build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread {
                    status.text = "Status: connected"
                    addLog("Connected to support server")
                }

                val id = Settings.Secure.getString(
                    contentResolver,
                    Settings.Secure.ANDROID_ID
                ) ?: UUID.randomUUID().toString()

                val msg = JSONObject()
                    .put("type", "register")
                    .put("deviceId", id)
                    .put("name", "Android Device")
                    .put("model", Build.MODEL)
                    .put("sdk", Build.VERSION.SDK_INT)

                webSocket.send(msg.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleMessage(JSONObject(text))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread {
                    status.text = "Status: disconnected"
                    addLog("Connection failed: ${t.message ?: "unknown error"}")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread {
                    status.text = "Status: closed"
                    addLog("Session closed")
                }
            }
        })
    }

    private fun handleMessage(msg: JSONObject) {
        when (msg.optString("type")) {
            "registered" -> {
                val code = msg.optString("pairCode", "-")
                runOnUiThread {
                    codeView.text = "Pair code: $code"
                    addLog("New pairing code generated")
                }
            }

            "remote_request" -> {
                val sessionId = msg.optString("sessionId")
                runOnUiThread {
                    addLog("Remote-support request received: $sessionId")

                    AlertDialog.Builder(this)
                        .setTitle("Remote Support Request")
                        .setMessage("A support operator requested a session. Approve?")
                        .setNegativeButton("Decline", null)
                        .setPositiveButton("Approve") { _, _ ->
                            socket.send(
                                JSONObject()
                                    .put("type", "approve_session")
                                    .put("sessionId", sessionId)
                                    .toString()
                            )
                            addLog("Session approved")
                        }
                        .show()
                }
            }

            "command_request" -> {
                val sessionId = msg.optString("sessionId")
                val command = msg.optString("command")

                val result = when (command) {
                    "PING" -> "PONG"
                    "DEVICE_INFO" -> JSONObject()
                        .put("model", Build.MODEL)
                        .put("sdk", Build.VERSION.SDK_INT)
                        .put("manufacturer", Build.MANUFACTURER)
                        .toString()
                    else -> "UNKNOWN_COMMAND"
                }

                socket.send(
                    JSONObject()
                        .put("type", "command_result")
                        .put("sessionId", sessionId)
                        .put("command", command)
                        .put("data", result)
                        .toString()
                )

                runOnUiThread {
                    addLog("Command handled: $command")
                }
            }

            "revoked" -> {
                runOnUiThread {
                    status.text = "Status: pairing revoked"
                    addLog("Pairing revoked by operator")
                }
            }
        }
    }

    private fun addLog(message: String) {
        logView.append("• $message\n")
    }

    override fun onDestroy() {
        if (::socket.isInitialized) socket.close(1000, "Activity closed")
        super.onDestroy()
    }
}
